//Walker Wood
//COMP 2710
//AUBIEBOOK APPLICATION




#include <iostream>
#include <string>
#include "System.h"

using namespace std; 


int main()
{
	System sys;
	sys.run();
	return 1;
}
